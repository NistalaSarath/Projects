package org.cap.dao;

import org.cap.model.Student;

public interface StudentDao {
	public void saveDetails(Student student);
}
