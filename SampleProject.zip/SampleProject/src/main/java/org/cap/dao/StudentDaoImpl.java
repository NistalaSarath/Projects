package org.cap.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.cap.model.Student;
import org.springframework.stereotype.Repository;

@Repository("studentdao")
@Transactional
public class StudentDaoImpl implements StudentDao{
@PersistenceContext
private EntityManager entitymanager;

	@Override
	public void saveDetails(Student student) {
		entitymanager.persist(student);
	}

}
