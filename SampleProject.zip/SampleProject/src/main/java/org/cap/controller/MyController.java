package org.cap.controller;

import org.cap.model.Student;
import org.cap.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MyController {
@Autowired	
private StudentService studentservice;
@RequestMapping("/Hello Java")
public String showHello() {
	 return "hello";
}
	@RequestMapping("/validateLogin")
	public String validatelogin(ModelMap map, 
			@RequestParam("Username") String username,
			@RequestParam("Password") String password) {
		if(username.equals("sarath") && password.equals("sarath777")) {
			map.put("student", new Student());
			return "main";
		}
		return "redirect:/";
	}
	@RequestMapping("/studentform")
	public String saveDetails(ModelMap map,@ModelAttribute("student") Student student) {
		int result=studentservice.saveDetails(student);
	map.put("student", student);
	
	return
	}
			
}
