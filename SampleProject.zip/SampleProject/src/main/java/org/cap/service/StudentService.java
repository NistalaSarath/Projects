package org.cap.service;

import org.cap.model.Student;

public interface StudentService {
	public int saveDetails(Student student);
}
