package org.cap.service;

import org.cap.dao.StudentDao;
import org.cap.model.Student;
import org.springframework.stereotype.Service;

@Service("studentservice")
public class StudentServiceImpl implements StudentService {
	
private StudentDao studentdao;
	@Override
	public int saveDetails(Student student) {
		
		return studentdao.saveDetails(student);
	}

}
