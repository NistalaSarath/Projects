package com.cg.walletjdbc.dao;


public interface QueryMapper {

	public static final String INSERT_QUERY="INSERT INTO Customer VALUES(customerId_sequence.NEXTVAL,?,?,?,?,?)";
	public static final String CUSTOMERID_QUERY_SEQUENCE="SELECT customerId_sequence.CURRVAL FROM DUAL";

	public static final String INSERT_INTO_WALLET="insert into wallet values(accno_sequence.NEXTVAL,?,?)";
	public static final String SELECT_FROM_WALLET="SELECT accno_sequence.CURRVAL FROM DUAL";
	
	public static final String SELECT_ACCBAL_FROM_WALLET="select balance from wallet where accno=?";
	public static final String UPDATE_ACCBAL="UPDATE WALLET SET balance=? where accno=?";

	public static final String INSERT_TRANSACTIONS="insert into Transactions values(transactionId_sequence.NEXTVAL,?,?,?,?,?)";
	public static final String SELECT_TRANSACTIONS="select * from Transactions where faccno=?";
	
}
