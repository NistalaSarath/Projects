package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IBookingDAO;
import com.cg.model.HotelDetails;
@Service("bookingservice")
public class BookingServiceImpl implements IBookingService {
	
	@Autowired
	private IBookingDAO bookingdao;
	@Override
	public List<HotelDetails> getProducts() {
		
		return bookingdao.getProducts();
	}
	@Override
	public HotelDetails findProduct(String id) {

		return bookingdao.findProduct(id);
	}
	@Override
	public void updateProduct(HotelDetails product2) {
		
		bookingdao.updateProduct(product2);
		
		
	}

}
