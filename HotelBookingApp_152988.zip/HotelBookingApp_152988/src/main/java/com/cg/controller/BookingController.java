package com.cg.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.model.HotelDetails;
import com.cg.service.IBookingService;
@Controller
public class BookingController {
	
	@Autowired
	private IBookingService bookingservice;
	
	private HotelDetails hdetails;
	
	@RequestMapping("/")
	public String showProduct(ModelMap map)
	{	
		List<HotelDetails> hd=bookingservice.getProducts();
		map.put("p1", hd);
		return "HotelDetails";
	}
	
		
	@RequestMapping("/update/{hotelname}")
	public String Bookmyroom(ModelMap map,@PathVariable("hotelname") String name)
	{
		map.put("name", name);
		return "HotelBooking";
	}	
	
		
	
	
	
}