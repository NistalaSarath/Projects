package com.cg.dao;

import java.util.List;

import com.cg.model.HotelDetails;
public interface IBookingDAO {

	public List<HotelDetails> getProducts();

	public HotelDetails findProduct(String id);

	public void updateProduct(HotelDetails product2);

}
