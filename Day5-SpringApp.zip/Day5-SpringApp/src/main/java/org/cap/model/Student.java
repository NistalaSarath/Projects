package org.cap.model;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="student")
public class Student {
	
	public Student(){
		
	}
	@Id
	@GeneratedValue
	@Column(name="studId")
	private int studId;
	@Column(name="StudName")
	private String StudName;
	@Column(name="studLocation")
	private String studLocation;
	
	public Student(int studId, String studName, String studLocation) {
		super();
		this.studId = studId;
		StudName = studName;
		this.studLocation = studLocation;
	}
	public int getStudId() {
		return studId;
	}
	public void setStudId(int studId) {
		this.studId = studId;
	}
	public String getStudName() {
		return StudName;
	}
	public void setStudName(String studName) {
		StudName = studName;
	}
	public String getstudLocation() {
		return studLocation;
	}
	public void setstudLocation(String studLocation) {
		this.studLocation = studLocation;
	}
	@Override
	public String toString() {
		return "Student [studId=" + studId + ", StudName=" + StudName + ", studLocation=" + studLocation + "]";
	}
	
}
