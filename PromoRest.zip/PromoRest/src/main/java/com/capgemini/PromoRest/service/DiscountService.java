package com.capgemini.PromoRest.service;

import java.util.List;

import com.capgemini.PromoRest.model.Discount;

public interface DiscountService {

	public List<Discount> getAll();

}
