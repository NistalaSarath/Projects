package org.cap.controller;

import java.util.List;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AccountController {

	@PostMapping("/validateLogin")
	public String validateLogin(ModelMap map, 
			@RequestParam("userName")String userName,
			@RequestParam("userPwd")String userPwd) {
		
		
		if(userName.equals("sarath") && 
				userPwd.equals("sarath123")) {
			
			return "main";
		}
		
		return "redirect:/";
	}
	
	@RequestMapping("/createAccount")
	public String showCreateAccountPage() {
		return "createAccount";
	}
	
	@RequestMapping("/showBalance")
	public String showShowBalancePage() {
		return "showBalance";
	}
	
	@RequestMapping("/deposit")
	public String showDepositPage() {
		return "deposit";
	}
	
	@RequestMapping("/withdraw")
	public String showWithdrawPage() {
		return "withdraw";
	}
	
	@RequestMapping("/fundTransfer")
	public String showFundTransferPage() {
		return "fundTransfer";
	}
	@RequestMapping("/transactionSummary")
	public String showTransactionSummaryPage() {
		return "transactionSummary";
	}
	
	@RequestMapping("/logout")
	public String showLogoutPage() {
		return "logout";
	}
	
	
	
	
	
	
	
}
