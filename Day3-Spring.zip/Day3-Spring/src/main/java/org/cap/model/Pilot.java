package org.cap.model;


import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Future;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
@Entity
public class Pilot {
	
	@GeneratedValue
	@Id
	private int pilotId;
	@NotEmpty(message="*Please Enter FirstName")
	private String FirstName;
	@NotEmpty(message="*Please Enter LastName")
	private String LastName;
	/*@Past(message="*Please Enter DOB")*/
	private Date dateofBirth;
	/*@Future(message="*Please Enter DOJ")*/
	private Date dateofJoining;
	private Boolean isCertified;
	@Range(min=10000,max=1000000,message="*Salary range should be between 10k to 10L")
	private double salary;
	
	public Pilot(int pilotId, String firstName, String lastName, Date dateofBirth, Date dateofJoining,
			Boolean isCertified, double salary) {
		super();
		this.pilotId = pilotId;
		FirstName = firstName;
		LastName = lastName;
		this.dateofBirth = dateofBirth;
		this.dateofJoining = dateofJoining;
		this.isCertified = isCertified;
		this.salary = salary;
	}

	

	public int getPilotId() {
		return pilotId;
	}

	public void setPilotId(int pilotId) {
		this.pilotId = pilotId;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public Date getDateofBirth() {
		return dateofBirth;
	}

	public void setDateofBirth(Date dateofBirth) {
		this.dateofBirth = dateofBirth;
	}

	public Date getDateofJoining() {
		return dateofJoining;
	}

	public void setDateofJoining(Date dateofJoining) {
		this.dateofJoining = dateofJoining;
	}

	public Boolean getIsCertified() {
		return isCertified;
	}

	public void setIsCertified(Boolean isCertified) {
		this.isCertified = isCertified;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Pilot() {
	}
	@Override
	public String toString() {
		return "Pilot [pilotId=" + pilotId + ", FirstName=" + FirstName + ", LastName=" + LastName + ", dateofBirth="
				+ dateofBirth + ", dateofJoining=" + dateofJoining + ", isCertified=" + isCertified + ", salary="
				+ salary + "]";
	}
}