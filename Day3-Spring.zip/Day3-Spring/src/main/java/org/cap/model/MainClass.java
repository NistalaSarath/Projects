package org.cap.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("jpademo");
		EntityManager em=factory.createEntityManager();
		em.getTransaction().begin();
		Pilot pilot =new Pilot();

	}

} 