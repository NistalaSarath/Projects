package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

//@Transactional
@Repository("PilotDao")
public class PilotDaoImpl implements PilotDao {
	
@PersistenceContext
private EntityManager entityManager;
	@Transactional
    @Override
	public void save(Pilot pilot) {
		entityManager.persist(pilot);
		// TODO Auto-generated method stub
		
	}
	@Transactional(readOnly=true)
	@Override
	public List<Pilot> getall() {
		List<Pilot> pilots=entityManager.createQuery("from Pilot").getResultList();
		return pilots;
	}
	@Transactional
	@Override
	public void delete(Integer pilotId) {
		Pilot pilot= entityManager.find(Pilot.class, pilotId);
		entityManager.remove(pilot);
		
	}

}
