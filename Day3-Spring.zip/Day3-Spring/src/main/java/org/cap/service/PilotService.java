package org.cap.service;

import java.util.List;

import org.cap.model.Pilot;

public interface PilotService {
	public void save(Pilot pilot);
	public List<Pilot> getall();
	public void delete(Integer pilotId);
}
