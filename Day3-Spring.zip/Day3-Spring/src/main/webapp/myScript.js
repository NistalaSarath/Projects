function validateForm() {
	alert('Hello!');
}