package org.cap.demo.controller;

import org.cap.demo.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;


import java.io.File;
import java.io.IOException;
import java.util.List;

@Controller
public class UploadingController {
    public static final String uploadingdir = System.getProperty("user.dir") + "/src/main/resources/static/uploadingdir/";

    @RequestMapping("/")
    public String uploading(Model model) {
        File file = new File(uploadingdir);
        model.addAttribute("files", file.listFiles());
        model.addAttribute("product", new Product());
        return "uploading";
    }

    @RequestMapping(value = "/", method = RequestMethod.POST)
    public String uploadingPost(@RequestParam("uploadingFiles") MultipartFile uploadingFiles,
    		@ModelAttribute("product") Product product) throws IOException {
    	int imgName=0;
      //  for(MultipartFile uploadedFile : uploadingFiles) {
            File file = new File(uploadingdir + uploadingFiles.getOriginalFilename());
            uploadingFiles.transferTo(file);
            
          
            
            
            String path=file.getPath();
            
           String extenstion= path.substring(path.lastIndexOf('.'), path.length());
            
            //product.setImgUrl("../uploadingdir/" +imgName+".jpg");
            
          //  productDao.save(product);
            
            System.out.println(extenstion);
            
            final String uri="http://localhost:8092/PilotRestApp/api/v3/maxId";
			RestTemplate restTemplate=new RestTemplate();
			
			Integer productId=(Integer)restTemplate.getForObject(uri, Integer.class);
            
            System.out.println("hii");
            //Integer productId=productDao.findMaxProductId();
            
           // System.out.println("pproduct id is"+productId);
           if(productId!=null)
            	imgName=productId+1;
            else
            	imgName=0;
            File file2=new File(uploadingdir+imgName+ extenstion);
            file.renameTo(file2);
            
            
            product.setImgUrl("../uploadingdir/" +imgName+ extenstion);
            
            
        	final String uri1="http://localhost:8092/PilotRestApp/api/v3/put1";
			RestTemplate restTemplate1=new RestTemplate();
			
		//	ResponseEntity<Pilot> pilot1=
					restTemplate1.postForEntity(uri1,product,Product.class);
            
            
            
           // productDao.save(product);
        //}

        return "redirect:show";
    }
    
    
    @RequestMapping("/show")
    public String showProducts(Model model) {
    	
    	//List<Product> products= productDao.findAll();
    	
    	 final String uri="http://localhost:8092/PilotRestApp/api/v3/getAll";
			RestTemplate restTemplate=new RestTemplate();
			
		Product[] products=
					restTemplate.getForObject(uri,Product[].class);
    	model.addAttribute("products", products);
    	return "show";
    }
}