package org.cap.demo.model;


/*@Entity
@Table(name="myproduct")*/
public class Product {
	
	/*@Id
	@GeneratedValue*/
	private int productId;
	private String productName;
	private String imgUrl;
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getImgUrl() {
		return imgUrl;
	}
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
	public Product(int productId, String productName, String imgUrl) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.imgUrl = imgUrl;
	}
	
	public Product() {
		
	}

}
