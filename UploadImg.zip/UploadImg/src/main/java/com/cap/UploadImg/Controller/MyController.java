package com.cap.UploadImg.Controller;

import java.io.File;
import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class MyController {
	/*@RequestMapping("/") 
	public String newFile() {
	System.out.println("I am in controller");
		return "uploadImage";
		
	}*/
	
	
	   public static final String uploadingdir = System.getProperty("user.dir") + "/src/main/resources/static/uploadingdir/";

	    
	    
	    @RequestMapping("/")
	    public String uploading(Model model) {
	        File file = new File(uploadingdir);
	        model.addAttribute("files", file.listFiles());
	        return "uploading";
	    }

	    @RequestMapping(value = "/", method = RequestMethod.POST)
	    public String uploadingPost(@RequestParam("uploadingFiles") MultipartFile[] uploadingFiles) throws IOException {
	        for(MultipartFile uploadedFile : uploadingFiles) {
	            File file = new File(uploadingdir + uploadedFile.getOriginalFilename());
	            uploadedFile.transferTo(file);
	        }

	        return "redirect:/";
	    }
	    
	   /* 
	    @RequestMapping("/show")
	    public void changeName()
	    {
	    	File file=new File("src\\main\\resources\\static\\uploadingdir\\123.jpg");
	    	File change=new File("src\\main\\resources\\static\\uploadingdir\\111.jpg");
	    	
	    	System.out.println(file.getAbsoluteFile()+"-"+file.getPath());
	    	
	    	if(file.renameTo(change)){
	    		System.out.println("Rename succesful");
	    		}else{
	    		System.out.println("Rename failed");
	    		}
	    }*/
	
	
	
	

}
