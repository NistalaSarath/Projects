package com.cap.UploadImg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UploadImgApplication {

	public static void main(String[] args) {
		SpringApplication.run(UploadImgApplication.class, args);
	}
}
