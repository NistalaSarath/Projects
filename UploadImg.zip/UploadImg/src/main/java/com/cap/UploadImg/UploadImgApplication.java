package com.cap.UploadImg;

import java.io.File;
import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cap.UploadImg.Controller.MyController;

@SpringBootApplication
public class UploadImgApplication {

	public static void main(String[] args) throws IOException{
		new File(MyController.uploadingdir).mkdirs();
		SpringApplication.run(UploadImgApplication.class, args);
	}
}
