package org.cap.main;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.cap.model.Pilot;

public class MainClass {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("jpademo");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		Pilot p = new Pilot();
		p.setPilotId(1001);
		p.setFirstName("Sarath");
		p.setLastName("Nistala");
		p.setDateofBirth(new Date());
		p.setDateofJoining(new Date());
		p.setSalary(1200000);
		p.setIsCertified(true);
		em.persist(p);
		em.getTransaction().commit();
		em.close();
		factory.close();
	}
	
	
	
}
