package org.cap.model;

public class Account {
	private int accountno;
	private Customer customer;
	private double openingBalance;
	
	public Account() {
	}
	
	
	public Account(int accountno, Customer customer, double openingBalance) {
		super();
		this.accountno = accountno;
		this.customer = customer;
		this.openingBalance = openingBalance;
	}
	public int getAccountno() {
		return accountno;
	}
	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public double getOpeningBalance() {
		return openingBalance;
	}
	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}
	@Override
	public String toString() {
		return "Account [accountno=" + accountno + ", customer=" + customer + ", openingBalance=" + openingBalance
				+ "]";
	}
	
}
