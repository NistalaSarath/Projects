
package createAccount;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.service.AccountServiceImpl;
import org.cap.service.IAccountService;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	private Customer customer;
	private double openingBalance;
	private IAccountService accountservice;
	
 	@Before
	public void setUp() {
		customer = new Customer();
		openingBalance = 1000;
		accountservice = new AccountServiceImpl();
	}
	@Given("^customer details$")
	public void customer_details() throws Throwable {
		customer.setFirstName("Sarath");
		customer.setLastName("Nistala");
		Address address = new Address();
		address.setCity("Hyderabad");
		address.setDoorNo(409);
		customer.setAddress(address);
	}

	@When("^valid Customer$")
	public void valid_Customer() throws Throwable {
	   assertNotNull(customer);
	}

	@When("^valid opening balance$")
	public void valid_opening_balance() throws Throwable {
	   assertTrue(openingBalance>=500);
	}

	@Then("^create new Account$")
	public void create_new_Account() throws Throwable {
		Account account = accountservice.createAccount(customer, openingBalance);
	    assertNotNull(account);
	    assertEquals(openingBalance,account.getOpeningBalance(),0.0);
	    assertEquals(1,account.getAccountno());
	}

}
