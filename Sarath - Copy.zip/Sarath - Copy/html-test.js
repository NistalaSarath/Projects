$(document).ready(function(){
$("#flip").click(function(){
        $("#x").slideToggle(500);
         $("#y").slideToggle(500);
          $("#z").slideToggle(500);
    });
	
	
	

	});