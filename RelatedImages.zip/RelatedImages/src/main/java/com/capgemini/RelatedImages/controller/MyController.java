package com.capgemini.RelatedImages.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.RelatedImages.model.Inventory;
import com.capgemini.RelatedImages.service.IImageService;

@Controller
public class MyController {

	@Autowired
	private IImageService imageService;
	
	@RequestMapping("/")
	public String uploadImagePage(ModelMap map)
	{
		List<Inventory> products=imageService.getAll();
		map.put("products", products);
		System.out.println("Sharath");
		return "relatedImage";
	}
	/*
	@RequestMapping("/upload")
	public String uploadImage(@ModelAttribute)*/
	
}
