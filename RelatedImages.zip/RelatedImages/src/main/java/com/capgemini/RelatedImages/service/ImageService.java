package com.capgemini.RelatedImages.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.RelatedImages.dao.IImageDao;
import com.capgemini.RelatedImages.model.Inventory;

@Service("imageService")
public class ImageService implements IImageService{

	@Autowired
	private IImageDao imageDao;

	@Override
	public List<Inventory> getAll() {
		
		return imageDao.findAll();
	}
	
	
}
