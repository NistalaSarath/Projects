package com.capgemini.RelatedImages.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.RelatedImages.model.Inventory;

@Repository("imageDao")
public interface IImageDao extends JpaRepository<Inventory, Integer>{

}
