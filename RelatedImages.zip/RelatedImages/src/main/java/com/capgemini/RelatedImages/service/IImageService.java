package com.capgemini.RelatedImages.service;

import java.util.List;

import com.capgemini.RelatedImages.model.Inventory;

public interface IImageService {

	public List<Inventory> getAll();
	
}
