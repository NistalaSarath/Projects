package org.cap.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="myproduct")
public class Product {
	
	@Id
	@GeneratedValue
	private int productId;
	private int imageId;
	private String productName;
	private String imgUrl;
	private boolean priority;
	
	public boolean isPriority() {
		return priority;
	}
	public int getImageId() {
		return imageId;
	}
	public void setImageId(int imageId) {
		this.imageId = imageId;
	}
	public void setPriority(boolean priority) {
		this.priority = priority;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getImgUrl() {
		return imgUrl;
	}
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
	
	
	
	public Product(int productId, int imageId, String productName, String imgUrl, boolean priority) {
		super();
		this.productId = productId;
		this.imageId = imageId;
		this.productName = productName;
		this.imgUrl = imgUrl;
		this.priority = priority;
	}
	public Product() {
		
	}

}
