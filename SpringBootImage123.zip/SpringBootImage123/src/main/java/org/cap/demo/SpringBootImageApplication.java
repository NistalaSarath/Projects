package org.cap.demo;

import org.cap.demo.controller.UploadingController;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.File;
import java.io.IOException;





@SpringBootApplication
public class SpringBootImageApplication  {

	public static void main(String[] args)throws IOException {
		new File(UploadingController.uploadingdir).mkdirs();
		new File(UploadingController.productname).mkdirs();
		new File(UploadingController.productid).mkdirs();
		new File(UploadingController.imageid).mkdirs();
		SpringApplication.run(SpringBootImageApplication.class, args);
	}
	
	
	
}
