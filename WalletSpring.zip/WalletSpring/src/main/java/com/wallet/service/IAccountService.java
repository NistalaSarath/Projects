package com.wallet.service;

import java.util.List;

import com.wallet.model.Account;

public interface IAccountService {
	public void createAccount(Account account);
	public List<Account> getAllAccounts(int customerId);
	public List<Account> getAccountWithBalance(int custId);		
}
