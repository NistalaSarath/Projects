package com.wallet.dao;

public interface WalletDao {


}
