package com.cg.wallet.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;

import com.cg.wallet.bean.Customer;
import com.cg.wallet.bean.Transactions;
import com.cg.wallet.bean.Wallet;
import com.cg.wallet.exception.WalletException;

public class WalletDaoImpl implements WalletDao {

	static HashMap<Integer,Customer> custmap=new HashMap<Integer,Customer>();
	static HashMap<Integer,Wallet> walletmap=new HashMap<Integer,Wallet>();
	Transactions transaction = new Transactions();
	static HashMap<Integer,Transactions> transactions=new HashMap<Integer,Transactions>();
	
	@Override
	public int createAccount(Customer customer) throws WalletException {

	try {
			if(custmap.size()==0)
			{
				customer.setId(1001);
			}
			else {
				Optional<Integer> id=custmap.keySet().stream().max((x,y)->x>y?1:x<y?-1:0);
				int custid=id.get()+1;
				customer.setId(custid);
			}
			custmap.put(customer.getId(), customer);
			return customer.getId();
			
		}
		catch(Exception ex)
		{
			throw new WalletException(ex.getMessage());
		}
	}

	@Override
	public int assignAccount(String type) throws WalletException {
		Wallet wallet=new Wallet();
		double balanceamount=0;

		try {
			if(walletmap.size()==0)
			{
				wallet.setAccountno(5001);
				wallet.setBalance(balanceamount);
			}
			else {
				Optional <Integer> account=walletmap.keySet().stream().max((x,y)->x>y?1:x<y?-1:0);
				int accno=account.get()+1;
				wallet.setAccountno(accno);
				wallet.setBalance(balanceamount);
			}
			
			walletmap.put(wallet.getAccountno(), wallet);

		}
		catch(Exception ex)
		{
			throw new WalletException(ex.getMessage());
		}
		return wallet.getAccountno();
	}

	@Override
	public double showBalance(int accno) throws WalletException {

		Wallet value=new Wallet();
		double balance=0;
		
		try {
			if(!walletmap.containsKey(accno))
			{
				throw new WalletException("Invalid Account number..!");
			}
			else {
					value=walletmap.get(accno);
					balance=value.getBalance();
					value.setBalance(balance);
					
				}

		}
		catch(Exception ex)
		{
			System.out.println("Error occured:"+ex.getMessage());
		}
		return balance;
	}

	@Override
	public double deposit(int accno, double amount) throws WalletException {

		Wallet value=new Wallet();
		double famount=0;
		try {
			if(!walletmap.containsKey(accno))
			{
				throw new WalletException("Invalid Account number..!");
			}
			else {
					value=walletmap.get(accno);
					famount=value.getBalance()+amount;
					System.out.println("!!!!!!!!Deposited!!!!!!!!");
					value.setBalance(famount);
					Transactions transaction=new Transactions();
					transaction.setAccno(accno);
					transaction.setTransactiontype("Deposit");
					transaction.setAmount(amount);
					transaction.setBalance(famount);
					transactions.put(accno, transaction);
				}

		}
		catch(Exception ex)
		{
			System.out.println("Error occured:"+ex.getMessage());
		}
		return famount;
	}

	@Override
	public int withdraw(int accno, double amount) throws WalletException {
		Wallet value=new Wallet();
		double famount=0;
		int status=0;
		try {
			if(!walletmap.containsKey(accno))
			{
				throw new WalletException("Invalid Account number..!");
			}
			else {
					value=walletmap.get(accno);
					famount=(int) (value.getBalance()-amount);
					value.setBalance(famount);
					status=1;
					Transactions transaction=new Transactions();
					transaction.setAccno(accno);
					transaction.setTransactiontype("Deposit");
					transaction.setAmount(amount);
					transaction.setBalance(famount);
					transactions.put(accno, transaction);
				}

		}
		catch(Exception ex)
		{
			System.out.println("Error occured:"+ex.getMessage());
		}
		return status;
	}

	@Override
	public int fundTransfer(int faccno, int taccno, double amount) throws WalletException {
		
		Wallet value1=new Wallet();	
		Wallet value2=new Wallet();

		
		double fromfinalamount=0;
		double tofinalamount=0;
		int status=0;
	
		try {
			if(!walletmap.containsKey(faccno)&&!walletmap.containsKey(taccno))
			{
				throw new WalletException("Invalid Account number..!");
			}
			else {
					value1=walletmap.get(faccno);
					value2=walletmap.get(taccno);

					fromfinalamount= (value1.getBalance()-amount);
					tofinalamount= (value2.getBalance()+amount);
					value1.setBalance(fromfinalamount);
					value2.setBalance(tofinalamount);
					
					Transactions transaction1=new Transactions();
					transaction1.setAccno(faccno);
					transaction1.setTransactiontype("Debited");
					transaction1.setAmount(amount);
					transaction1.setBalance(fromfinalamount);
					transactions.put(faccno, transaction);
					
					Transactions transaction2=new Transactions();
					transaction2.setAccno(taccno);
					transaction2.setTransactiontype("Deposit");
					transaction2.setAmount(amount);
					transaction2.setBalance(tofinalamount);
					transactions.put(taccno, transaction);
					status=1;
				}

		}
		catch(Exception ex)
		{
			System.out.println("Error occured:"+ex.getMessage());
		}
		return status;
	
	}

	@Override
	public Transactions printTransactions(int accno) throws WalletException {
		try {
			Transactions transaction=transactions.get(accno);
			if(transaction==null) {
				throw new WalletException("Customer with the Account number"+accno+" not available");
			}
			else {
				/*Iterator<Transactions> iter=transactions.iterator();
				while(iter.hasNext()) {
					
				}*/
				
				System.out.println(transaction);
			}
		
		return transaction;
	} catch(Exception ex) {
		throw new WalletException(ex.getMessage());
	}
	
	}
}

