package com.cg.wallet.Test;

import org.junit.jupiter.api.Test;

import com.cg.wallet.bean.Wallet;
import com.cg.wallet.dao.WalletDaoImpl;
import com.cg.wallet.exception.WalletException;
import com.cg.wallet.service.WalletServiceImpl;

import junit.framework.Assert;
import junit.framework.TestCase;

public class WalletServiceImplTest extends TestCase {

	
@Test
	public void testValidateName() throws WalletException {
WalletServiceImpl w=new WalletServiceImpl();

Assert.assertEquals(true, w.validateName("Dhoni"));
	}

	public void testValidatePhone() throws WalletException {
		WalletServiceImpl w=new WalletServiceImpl();

		Assert.assertEquals(true, w.validatePhone("8995769753"));
	}
@Test
	public void testCreateAccount() {
		WalletDaoImpl w=new WalletDaoImpl();
		Wallet a=new Wallet();
		Assert.assertEquals(5001, 5001);
	}

@Test
	public void testValidateNamefail()  {
		WalletServiceImpl c=new WalletServiceImpl();

		
			try {
				Assert.assertEquals(false, c.validateName("m@honi"));
			} catch (WalletException e) {
				
			
			}
		
			}
@Test
	public void testValidatePhonefail()  {
		WalletServiceImpl w=new WalletServiceImpl();

		
			try {
				Assert.assertEquals(false, w.validatePhone("822222299576"));
			} catch (WalletException e) {
			
		
			}
		
			
			
		}
	}
	
	

