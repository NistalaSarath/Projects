package com.capg.demo.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import com.capg.demo.dao.UploadImageInterface;
import com.capg.demo.model.Product;



@Service("pilotDBService")
public class PilotServiceImpl implements PilotServiceInterface {
	@Autowired
	private UploadImageInterface uploadImageDBdao;
	/*@Override
	public List<UploadImage> getAllImage() {
		// TODO Auto-generated method stub
		return uploadImageDBdao.findAll();
	}*/
	@Override
	public int getMaxId() {
		// TODO Auto-generated method stub
		return uploadImageDBdao.findMaxProductId();
	}
	@Override
	public void save(Product product) {
		// TODO Auto-generated method stub
		uploadImageDBdao.save(product);
	}
	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return uploadImageDBdao.findAll();
	}
	
		// TODO Auto-generated method stub
		//return uploadImageDBdao.get;
	

	/*@Autowired
	private PilotDaoInterface pilotDBdao;
	
	@Autowired
	private InventoryDaoInterface inventoryDBdao;

	
	@Autowired
	private EmailDaoInterface emailDBdao;
	@Override
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return pilotDBdao.findAll();
	}

	@Override
	public List<Inventory> getAllInventory() {
		// TODO Auto-generated method stub
		return inventoryDBdao.findAll();
		
	}

	@Override
	public void saveMail(Email mail) {
		// TODO Auto-generated method stub
		System.out.println("I am in service");
		emailDBdao.saveAndFlush(mail);
	}*/
	
	
	/*@Override
	public List<Pilot> getAllPilots() {
		
	return pilotDBdao.findAll();
	}*/
	/*@Override
	public Pilot findPilot(Integer pilotId) {
		System.out.println("pilot id of find is:"+pilotId);
		return pilotDBdao.getOne(pilotId);
	}
	@Override
	public List<Pilot> deletePilot(Integer pilotId) {
		System.out.println("pilot id of delete is:"+pilotId);
		pilotDBdao.deleteById(pilotId);
		
		return pilotDBdao.findAll();
	}
	@Override
	public List<Pilot> createPilot(Pilot pilot) {
		pilotDBdao.save(pilot);
		return pilotDBdao.findAll();
	}
	@Override
	public List<Pilot> updatePilot(Pilot pilot) {
		
		pilotDBdao.delete(pilot);
		
			pilotDBdao.save(pilot);
		return pilotDBdao.findAll();
	}
	@Override
	public void save(Pilot pilot) {
		pilotDBdao.save(pilot);
		
	}*/



}
